"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const database_1 = require("../config/database");
const auth_1 = require("../middleware/auth");
const router = express_1.default.Router();
// Group Admin: Create task
router.post('/', auth_1.verifyToken, auth_1.requireGroupAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        const { title, description, assignedTo, priority, dueDate } = req.body;
        const result = yield client.query(`INSERT INTO employee_tasks (
        title, description, assigned_to, assigned_by, priority, due_date
      ) VALUES ($1, $2, $3, $4, $5, $6) 
      RETURNING *`, [title, description, assignedTo, (_a = req.user) === null || _a === void 0 ? void 0 : _a.id, priority, dueDate]);
        res.json(result.rows[0]);
    }
    catch (error) {
        console.error('Error creating task:', error);
        res.status(500).json({ error: 'Failed to create task' });
    }
    finally {
        client.release();
    }
}));
// Employee: Update task status
router.patch('/:taskId/status', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    const client = yield database_1.pool.connect();
    try {
        const { taskId } = req.params;
        const { status } = req.body;
        // Get current task
        const currentTask = yield client.query('SELECT status_history FROM employee_tasks WHERE id = $1 AND assigned_to = $2', [taskId, (_a = req.user) === null || _a === void 0 ? void 0 : _a.id]);
        if (currentTask.rows.length === 0) {
            return res.status(404).json({ error: 'Task not found' });
        }
        // Update status history
        const statusHistory = currentTask.rows[0].status_history || [];
        statusHistory.push({
            status,
            updatedAt: new Date(),
            updatedBy: (_b = req.user) === null || _b === void 0 ? void 0 : _b.id
        });
        const result = yield client.query(`UPDATE employee_tasks 
       SET status = $1, 
           status_history = $2::jsonb,
           last_status_update = CURRENT_TIMESTAMP,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 AND assigned_to = $4
       RETURNING *`, [status, JSON.stringify(statusHistory), taskId, (_c = req.user) === null || _c === void 0 ? void 0 : _c.id]);
        res.json(result.rows[0]);
    }
    catch (error) {
        console.error('Error updating task status:', error);
        res.status(500).json({ error: 'Failed to update task status' });
    }
    finally {
        client.release();
    }
}));
// Get tasks for employee
router.get('/employee', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        // Get today's date in YYYY-MM-DD format
        const today = new Date().toISOString().split('T')[0];
        const result = yield client.query(`SELECT 
        t.*,
        u.name as assigned_by_name
       FROM employee_tasks t
       LEFT JOIN users u ON t.assigned_by = u.id
       WHERE t.assigned_to = $1
       AND DATE(t.due_date) = $2
       ORDER BY 
         CASE t.priority
           WHEN 'high' THEN 1
           WHEN 'medium' THEN 2
           WHEN 'low' THEN 3
         END,
         t.created_at DESC`, [(_a = req.user) === null || _a === void 0 ? void 0 : _a.id, today]);
        res.json(result.rows);
    }
    catch (error) {
        console.error('Error fetching tasks:', error);
        res.status(500).json({ error: 'Failed to fetch tasks' });
    }
    finally {
        client.release();
    }
}));
// Group Admin: Get all tasks
router.get('/admin', auth_1.verifyToken, auth_1.requireGroupAdmin, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        const result = yield client.query(`SELECT 
        t.*,
        u1.name as employee_name,
        u2.name as assigned_by_name,
        COALESCE(
          (
            SELECT jsonb_agg(
              jsonb_build_object(
                'status', (sh->>'status'),
                'updatedAt', (sh->>'updatedAt'),
                'updatedBy', (sh->>'updatedBy')::integer,
                'updatedByName', u3.name
              )
            )
            FROM jsonb_array_elements(t.status_history) sh
            LEFT JOIN users u3 ON (sh->>'updatedBy')::integer = u3.id
          ),
          '[]'::jsonb
        ) as status_history
       FROM employee_tasks t
       LEFT JOIN users u1 ON t.assigned_to = u1.id
       LEFT JOIN users u2 ON t.assigned_by = u2.id
       WHERE t.assigned_by = $1
       ORDER BY t.created_at DESC`, [(_a = req.user) === null || _a === void 0 ? void 0 : _a.id]);
        console.log('Tasks query result:', result.rows); // Debug log
        res.json(result.rows);
    }
    catch (error) {
        console.error('Detailed error in tasks fetch:', error);
        res.status(500).json({
            error: 'Failed to fetch tasks',
            details: error instanceof Error ? error.message : 'Unknown error'
        });
    }
    finally {
        client.release();
    }
}));
exports.default = router;
