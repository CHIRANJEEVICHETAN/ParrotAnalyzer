"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireGroupAdmin = exports.requireSuperAdmin = exports.verifyToken = exports.JWT_SECRET = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = require("../config/database");
exports.JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const verifyToken = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('\n=== Token Verification Start ===');
        const authHeader = req.headers.authorization;
        console.log('Authorization header present:', !!authHeader);
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            console.log('Invalid or missing authorization header');
            return res.status(401).json({ error: 'Authentication required' });
        }
        const token = authHeader.split(' ')[1];
        console.log('Token extracted, verifying...');
        try {
            const decoded = jsonwebtoken_1.default.verify(token, exports.JWT_SECRET);
            console.log('Token verified successfully, decoded payload:', {
                id: decoded.id,
                role: decoded.role
            });
            const client = yield database_1.pool.connect();
            try {
                const result = yield client.query(`SELECT u.id, u.name, u.email, u.role, u.company_id, c.status as company_status
           FROM users u
           LEFT JOIN companies c ON u.company_id = c.id
           WHERE u.id = $1`, [decoded.id]);
                if (!result.rows.length) {
                    console.log('User not found in database');
                    return res.status(401).json({ error: 'User not found' });
                }
                const user = result.rows[0];
                console.log('User found in database:', {
                    id: user.id,
                    role: user.role
                });
                req.user = user;
                next();
            }
            finally {
                client.release();
            }
        }
        catch (error) {
            console.error('Token verification failed:', error);
            if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
                return res.status(401).json({ error: 'Token expired' });
            }
            return res.status(401).json({ error: 'Invalid token' });
        }
    }
    catch (error) {
        console.error('Middleware error:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});
exports.verifyToken = verifyToken;
const requireSuperAdmin = (req, res, next) => {
    var _a;
    if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'super-admin') {
        return res.status(403).json({ error: 'Access denied. Super admin only.' });
    }
    next();
};
exports.requireSuperAdmin = requireSuperAdmin;
const requireGroupAdmin = (req, res, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (!req.user) {
            return res.status(401).json({ error: 'Authentication required' });
        }
        if (req.user.role !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group Admin only.' });
        }
        next();
    }
    catch (error) {
        console.error('Group Admin middleware error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
exports.requireGroupAdmin = requireGroupAdmin;
