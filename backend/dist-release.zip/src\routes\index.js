"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tasksRoutes = void 0;
var tasks_1 = require("./tasks");
Object.defineProperty(exports, "tasksRoutes", { enumerable: true, get: function () { return __importDefault(tasks_1).default; } });
