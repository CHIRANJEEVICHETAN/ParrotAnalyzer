"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const multer_1 = __importDefault(require("multer"));
const sync_1 = require("csv-parse/sync");
const database_1 = require("../config/database");
const auth_1 = require("../middleware/auth");
const upload = (0, multer_1.default)();
const router = express_1.default.Router();
// Get group admins list
router.get('/', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    try {
        if (!['management', 'super-admin'].includes(((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) || '')) {
            return res.status(403).json({ error: 'Access denied' });
        }
        const result = yield database_1.pool.query(`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.phone,
        u.created_at,
        c.name as company_name
      FROM users u
      JOIN companies c ON u.company_id = c.id
      WHERE u.role = 'group-admin'
      AND (
        $1 = 'super-admin' 
        OR 
        (u.company_id = (SELECT company_id FROM users WHERE id = $2))
      )
      ORDER BY u.created_at DESC
    `, [(_b = req.user) === null || _b === void 0 ? void 0 : _b.role, (_c = req.user) === null || _c === void 0 ? void 0 : _c.id]);
        res.json(result.rows);
    }
    catch (error) {
        console.error('Error fetching group admins:', error);
        res.status(500).json({ error: 'Failed to fetch group admins' });
    }
}));
// Create single group admin
router.post('/', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    const client = yield database_1.pool.connect();
    try {
        if (!['management', 'super-admin'].includes(((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) || '')) {
            return res.status(403).json({ error: 'Access denied' });
        }
        const { name, email, phone, password } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({
                error: 'Missing required fields'
            });
        }
        yield client.query('BEGIN');
        let companyId;
        if (((_b = req.user) === null || _b === void 0 ? void 0 : _b.role) === 'super-admin') {
            companyId = req.body.company_id;
            if (!companyId) {
                return res.status(400).json({ error: 'Company ID is required for super admin' });
            }
        }
        else {
            const userResult = yield client.query('SELECT company_id FROM users WHERE id = $1', [(_c = req.user) === null || _c === void 0 ? void 0 : _c.id]);
            companyId = userResult.rows[0].company_id;
        }
        const companyResult = yield client.query('SELECT status FROM companies WHERE id = $1', [companyId]);
        if (!companyResult.rows.length || companyResult.rows[0].status !== 'active') {
            yield client.query('ROLLBACK');
            return res.status(400).json({ error: 'Invalid or inactive company' });
        }
        const salt = yield bcrypt_1.default.genSalt(10);
        const hashedPassword = yield bcrypt_1.default.hash(password, salt);
        const result = yield client.query(`INSERT INTO users (name, email, phone, password, role, company_id)
       VALUES ($1, $2, $3, $4, 'group-admin', $5)
       RETURNING id, name, email, phone, created_at`, [name, email, phone || null, hashedPassword, companyId]);
        yield client.query('COMMIT');
        res.status(201).json(result.rows[0]);
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error creating group admin:', error);
        res.status(500).json({ error: 'Failed to create group admin' });
    }
    finally {
        client.release();
    }
}));
// Bulk create group admins from CSV
router.post('/bulk', auth_1.verifyToken, upload.single('file'), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g;
    const client = yield database_1.pool.connect();
    try {
        if (!['management', 'super-admin'].includes(((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) || '')) {
            return res.status(403).json({ error: 'Access denied' });
        }
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        yield client.query('BEGIN');
        let companyId;
        if (((_b = req.user) === null || _b === void 0 ? void 0 : _b.role) === 'super-admin') {
            companyId = req.body.company_id;
            if (!companyId) {
                return res.status(400).json({ error: 'Company ID is required' });
            }
        }
        else {
            const userResult = yield client.query('SELECT company_id FROM users WHERE id = $1', [(_c = req.user) === null || _c === void 0 ? void 0 : _c.id]);
            companyId = userResult.rows[0].company_id;
        }
        const fileContent = req.file.buffer.toString();
        const parsedRows = (0, sync_1.parse)(fileContent, {
            skip_empty_lines: true,
            trim: true
        });
        if (parsedRows.length < 2) {
            return res.status(400).json({ error: 'File is empty or missing headers' });
        }
        const headerRow = parsedRows[0];
        const headers = {};
        headerRow.forEach((header, index) => {
            headers[header.toLowerCase()] = index;
        });
        const results = [];
        const errors = [];
        for (let i = 1; i < parsedRows.length; i++) {
            const row = parsedRows[i];
            try {
                const groupAdmin = {
                    name: (_d = row[headers['name']]) === null || _d === void 0 ? void 0 : _d.trim(),
                    email: (_e = row[headers['email']]) === null || _e === void 0 ? void 0 : _e.trim(),
                    phone: (_f = row[headers['phone']]) === null || _f === void 0 ? void 0 : _f.trim(),
                    password: (_g = row[headers['password']]) === null || _g === void 0 ? void 0 : _g.trim()
                };
                if (!groupAdmin.name || !groupAdmin.email || !groupAdmin.password) {
                    errors.push({ row: i + 1, error: 'Missing required fields' });
                    continue;
                }
                const salt = yield bcrypt_1.default.genSalt(10);
                const hashedPassword = yield bcrypt_1.default.hash(groupAdmin.password, salt);
                const result = yield client.query(`INSERT INTO users (name, email, phone, password, role, company_id)
           VALUES ($1, $2, $3, $4, 'group-admin', $5)
           RETURNING id, name, email, phone`, [
                    groupAdmin.name,
                    groupAdmin.email,
                    groupAdmin.phone,
                    hashedPassword,
                    companyId
                ]);
                results.push(result.rows[0]);
            }
            catch (error) {
                errors.push({ row: i + 1, error: 'Failed to create group admin' });
            }
        }
        yield client.query('COMMIT');
        res.status(201).json({ success: results, errors });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error in bulk create:', error);
        res.status(500).json({ error: 'Failed to process bulk creation' });
    }
    finally {
        client.release();
    }
}));
exports.default = router;
