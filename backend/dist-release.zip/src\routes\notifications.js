"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const database_1 = require("../config/database");
const auth_1 = require("../middleware/auth");
const router = express_1.default.Router();
// Apply verifyToken middleware to all routes
router.use(auth_1.verifyToken);
// Get user's notifications (root route)
router.get('/', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    console.log('GET /api/notifications accessed');
    console.log('Request headers:', req.headers);
    console.log('User from token:', req.user);
    const client = yield database_1.pool.connect();
    try {
        if (!req.user) {
            console.log('No user found in request');
            return res.status(401).json({ error: 'Authentication required' });
        }
        const result = yield client.query(`
      SELECT 
        id,
        title,
        message,
        type,
        read,
        created_at
      FROM notifications
      WHERE user_id = $1
      ORDER BY created_at DESC`, [req.user.id]);
        console.log('Query executed successfully');
        console.log('Notifications found:', result.rows.length);
        res.json(result.rows);
    }
    catch (error) {
        console.error('Error in notifications route:', error);
        res.status(500).json({
            error: 'Failed to fetch notifications',
            details: error instanceof Error ? error.message : 'Unknown error occurred'
        });
    }
    finally {
        client.release();
    }
}));
// Test route
router.get('/test', (req, res) => {
    res.json({
        message: 'Notifications router is working',
        user: req.user
    });
});
// Mark notification as read
router.post('/:id/read', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const client = yield database_1.pool.connect();
    try {
        if (!req.user) {
            return res.status(401).json({ error: 'Authentication required' });
        }
        const result = yield client.query(`
      UPDATE notifications
      SET read = true
      WHERE id = $1 AND user_id = $2
      RETURNING *`, [req.params.id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Notification not found' });
        }
        res.json(result.rows[0]);
    }
    catch (error) {
        console.error('Error marking notification as read:', error);
        res.status(500).json({
            error: 'Failed to mark notification as read',
            details: error instanceof Error ? error.message : 'Unknown error occurred'
        });
    }
    finally {
        client.release();
    }
}));
exports.default = router;
