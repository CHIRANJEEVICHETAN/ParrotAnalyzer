"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const database_1 = require("../config/database");
const auth_1 = require("../middleware/auth");
const multer_1 = __importDefault(require("multer"));
const sync_1 = require("csv-parse/sync");
const upload = (0, multer_1.default)();
const router = express_1.default.Router();
// Get employees for a group admin
router.get('/employees', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group admin only.' });
        }
        const result = yield client.query(`
      SELECT 
        u.id,
        u.name,
        u.email,
        u.phone,
        u.employee_number,
        u.department,
        u.designation,
        u.created_at,
        u.can_submit_expenses_anytime,
        u.shift_status
      FROM users u
      WHERE u.group_admin_id = $1
      AND u.role = 'employee'
      ORDER BY u.created_at DESC
    `, [req.user.id]);
        res.json(result.rows);
    }
    catch (error) {
        console.error('Error fetching employees:', error);
        res.status(500).json({ error: 'Failed to fetch employees' });
    }
    finally {
        client.release();
    }
}));
// Create single employee
router.post('/employees', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group admin only.' });
        }
        const { name, employeeNumber, email, phone, password, department, designation, can_submit_expenses_anytime } = req.body;
        // Validate required fields
        if (!name || !email || !password || !employeeNumber || !department) {
            return res.status(400).json({
                error: 'Missing required fields',
                errors: {
                    name: !name ? 'Name is required' : null,
                    employeeNumber: !employeeNumber ? 'Employee number is required' : null,
                    email: !email ? 'Email is required' : null,
                    password: !password ? 'Password is required' : null,
                    department: !department ? 'Department is required' : null
                }
            });
        }
        yield client.query('BEGIN');
        // Get group admin's company_id
        const groupAdminResult = yield client.query('SELECT company_id FROM users WHERE id = $1', [req.user.id]);
        if (!groupAdminResult.rows.length || !groupAdminResult.rows[0].company_id) {
            throw new Error('Group admin company not found');
        }
        const company_id = groupAdminResult.rows[0].company_id;
        // Check if email or employee number exists
        const existingUser = yield client.query('SELECT id FROM users WHERE email = $1 OR employee_number = $2', [email, employeeNumber]);
        if (existingUser.rows.length > 0) {
            yield client.query('ROLLBACK');
            return res.status(409).json({
                error: 'Email or Employee Number already exists'
            });
        }
        // Hash password
        const salt = yield bcrypt_1.default.genSalt(10);
        const hashedPassword = yield bcrypt_1.default.hash(password, salt);
        // Create employee
        const result = yield client.query(`INSERT INTO users (
        name, 
        employee_number,
        email, 
        phone, 
        password, 
        role, 
        department,
        designation,
        group_admin_id,
        company_id, 
        can_submit_expenses_anytime
      ) VALUES ($1, $2, $3, $4, $5, 'employee', $6, $7, $8, $9, $10)
      RETURNING id, name, employee_number, email, phone, department, designation, created_at, can_submit_expenses_anytime`, [
            name,
            employeeNumber,
            email,
            phone || null,
            hashedPassword,
            department,
            designation || null,
            req.user.id,
            company_id,
            can_submit_expenses_anytime || false
        ]);
        yield client.query('COMMIT');
        res.status(201).json(result.rows[0]);
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error creating employee:', error);
        res.status(500).json({ error: 'Failed to create employee' });
    }
    finally {
        client.release();
    }
}));
// Bulk create employees from CSV
router.post('/employees/bulk', auth_1.verifyToken, upload.single('file'), (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j;
    const client = yield database_1.pool.connect();
    try {
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group admin only.' });
        }
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }
        yield client.query('BEGIN');
        // Get group admin's company_id
        const groupAdminResult = yield client.query('SELECT company_id FROM users WHERE id = $1', [req.user.id]);
        const company_id = groupAdminResult.rows[0].company_id;
        // Parse CSV
        const fileContent = req.file.buffer.toString();
        const parsedRows = (0, sync_1.parse)(fileContent, {
            skip_empty_lines: true,
            trim: true
        });
        const headers = {};
        parsedRows[0].forEach((header, index) => {
            headers[header.toLowerCase()] = index;
        });
        const results = [];
        const errors = [];
        // Process each row (skip header)
        for (let i = 1; i < parsedRows.length; i++) {
            const row = parsedRows[i];
            try {
                const employee = {
                    name: (_b = row[headers['name']]) === null || _b === void 0 ? void 0 : _b.trim(),
                    email: (_c = row[headers['email']]) === null || _c === void 0 ? void 0 : _c.trim(),
                    phone: (_d = row[headers['phone']]) === null || _d === void 0 ? void 0 : _d.trim(),
                    password: (_e = row[headers['password']]) === null || _e === void 0 ? void 0 : _e.trim(),
                    employee_number: (_f = row[headers['employee_number']]) === null || _f === void 0 ? void 0 : _f.trim(),
                    department: (_g = row[headers['department']]) === null || _g === void 0 ? void 0 : _g.trim(),
                    designation: (_h = row[headers['designation']]) === null || _h === void 0 ? void 0 : _h.trim(),
                    can_submit_expenses_anytime: ((_j = row[headers['can_submit_expenses_anytime']]) === null || _j === void 0 ? void 0 : _j.trim().toLowerCase()) === 'true'
                };
                // Validate required fields
                if (!employee.name || !employee.email || !employee.password || !employee.employee_number || !employee.department) {
                    errors.push({ row: i + 1, error: 'Missing required fields' });
                    continue;
                }
                // Check if email or employee number exists
                const existingUser = yield client.query('SELECT id FROM users WHERE email = $1 OR employee_number = $2', [employee.email, employee.employee_number]);
                if (existingUser.rows.length > 0) {
                    errors.push({ row: i + 1, error: 'Email or Employee Number already exists' });
                    continue;
                }
                // Hash password
                const salt = yield bcrypt_1.default.genSalt(10);
                const hashedPassword = yield bcrypt_1.default.hash(employee.password, salt);
                // Create employee
                const result = yield client.query(`INSERT INTO users (
            name, 
            employee_number,
            email, 
            phone, 
            password, 
            role, 
            department,
            designation,
            group_admin_id,
            company_id, 
            can_submit_expenses_anytime
          ) VALUES ($1, $2, $3, $4, $5, 'employee', $6, $7, $8, $9, $10)
          RETURNING id, name, employee_number, email, phone, department, designation`, [
                    employee.name,
                    employee.employee_number,
                    employee.email,
                    employee.phone,
                    hashedPassword,
                    employee.department,
                    employee.designation,
                    req.user.id,
                    company_id,
                    employee.can_submit_expenses_anytime
                ]);
                results.push(result.rows[0]);
            }
            catch (error) {
                errors.push({ row: i + 1, error: 'Failed to create employee' });
            }
        }
        yield client.query('COMMIT');
        res.status(201).json({ success: results, errors });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error in bulk create:', error);
        res.status(500).json({ error: 'Failed to process bulk creation' });
    }
    finally {
        client.release();
    }
}));
// Update employee access permission
router.patch('/employees/:id/access', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group admin only.' });
        }
        const { id } = req.params;
        const { can_submit_expenses_anytime } = req.body;
        const result = yield client.query(`UPDATE users 
       SET can_submit_expenses_anytime = $1
       WHERE id = $2 AND group_admin_id = $3 AND role = 'employee'
       RETURNING id, name, email, can_submit_expenses_anytime`, [can_submit_expenses_anytime, id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Employee not found' });
        }
        res.json(result.rows[0]);
    }
    catch (error) {
        console.error('Error updating employee access:', error);
        res.status(500).json({ error: 'Failed to update employee access' });
    }
    finally {
        client.release();
    }
}));
// Delete employee
router.delete('/employees/:id', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    const client = yield database_1.pool.connect();
    try {
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.role) !== 'group-admin') {
            return res.status(403).json({ error: 'Access denied. Group admin only.' });
        }
        const { id } = req.params;
        yield client.query('BEGIN');
        const result = yield client.query('DELETE FROM users WHERE id = $1 AND group_admin_id = $2 AND role = \'employee\' RETURNING id', [id, req.user.id]);
        if (result.rows.length === 0) {
            yield client.query('ROLLBACK');
            return res.status(404).json({ error: 'Employee not found' });
        }
        yield client.query('COMMIT');
        res.json({ message: 'Employee deleted successfully' });
    }
    catch (error) {
        yield client.query('ROLLBACK');
        console.error('Error deleting employee:', error);
        res.status(500).json({ error: 'Failed to delete employee' });
    }
    finally {
        client.release();
    }
}));
exports.default = router;
