"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const database_1 = require("./src/config/database");
const auth_1 = __importDefault(require("./src/routes/auth"));
const expenses_1 = __importDefault(require("./src/routes/expenses"));
const companies_1 = __importDefault(require("./src/routes/companies"));
const schedule_1 = __importDefault(require("./src/routes/schedule"));
const group_admin_1 = __importDefault(require("./src/routes/group-admin"));
const users_1 = __importDefault(require("./src/routes/users"));
const employee_1 = __importDefault(require("./src/routes/employee"));
const group_admins_1 = __importDefault(require("./src/routes/group-admins"));
const tasks_1 = __importDefault(require("./src/routes/tasks"));
const notifications_1 = __importDefault(require("./src/routes/notifications"));
dotenv_1.default.config();
const app = (0, express_1.default)();
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// Debug middleware to log all requests
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} ${req.method} ${req.url}`);
    console.log('Headers:', req.headers);
    next();
});
// Routes
app.use('/auth', auth_1.default);
app.use('/api/expenses', expenses_1.default);
app.use('/api/companies', companies_1.default);
app.use('/api/schedule', schedule_1.default);
app.use('/api/group-admin', group_admin_1.default);
app.use('/api/users', users_1.default);
app.use('/api/employee', employee_1.default);
app.use('/api/group-admins', group_admins_1.default);
app.use('/api/tasks', tasks_1.default);
app.use('/api/notifications', notifications_1.default);
// Test route at root level
app.get('/api/test', (req, res) => {
    res.json({ message: 'API is working' });
});
// Route not found handler
app.use((req, res, next) => {
    console.log('Route not found:', req.method, req.path);
    res.status(404).json({
        error: 'Route not found',
        path: req.path,
        method: req.method
    });
});
// Basic error handling
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal Server Error' });
});
const PORT = process.env.PORT || 3000;
// Initialize database and start server
(0, database_1.initDB)().then(() => {
    (0, database_1.seedUsers)().then(() => {
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log('Available routes:');
            console.log('- /auth/*');
            console.log('- /api/expenses/*');
            console.log('- /api/companies/*');
            console.log('- /api/schedule/*');
            console.log('- /api/group-admin/*');
            console.log('- /api/users/*');
            console.log('- /api/employee/*');
            console.log('- /api/group-admins/*');
            console.log('- /api/tasks/*');
            console.log('- /api/notifications/*');
        });
    });
}).catch(error => {
    console.error('Failed to initialize database:', error);
    console.log('Server is not running');
    process.exit(1);
});
