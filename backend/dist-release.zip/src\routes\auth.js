"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const crypto_1 = __importDefault(require("crypto"));
const nodemailer_1 = __importDefault(require("nodemailer"));
const database_1 = require("../config/database");
const auth_1 = require("../middleware/auth");
const auth_2 = require("../middleware/auth");
const router = express_1.default.Router();
// Store reset tokens (in production, use Redis or database)
const resetTokens = new Map();
router.post('/login', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const client = yield database_1.pool.connect();
    try {
        const { identifier, password } = req.body;
        console.log('Login attempt:', { identifier });
        const isEmail = identifier.includes('@');
        const query = isEmail
            ? 'SELECT * FROM users WHERE email = $1'
            : 'SELECT * FROM users WHERE phone = $1';
        const result = yield client.query(query, [identifier]);
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const user = result.rows[0];
        console.log('User found:', {
            id: user.id,
            role: user.role,
            name: user.name
        });
        const validPassword = yield bcrypt_1.default.compare(password, user.password);
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        const token = jsonwebtoken_1.default.sign({
            id: user.id,
            role: user.role,
            company_id: user.company_id
        }, auth_2.JWT_SECRET, { expiresIn: '24h' });
        console.log('Generated token payload:', {
            id: user.id,
            role: user.role,
            company_id: user.company_id
        });
        res.json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role,
                company_id: user.company_id
            }
        });
    }
    catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Failed to login' });
    }
    finally {
        client.release();
    }
}));
router.post('/forgot-password', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email } = req.body;
        const user = yield database_1.pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (user.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        const otp = crypto_1.default.randomInt(100000, 999999).toString();
        const expires = new Date(Date.now() + 30 * 60 * 1000); // 30 minutes
        resetTokens.set(email, {
            email,
            token: otp,
            expires,
        });
        const transporter = nodemailer_1.default.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS,
            },
        });
        yield transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Password Reset Code',
            text: `Your password reset code is: ${otp}. This code will expire in 30 minutes.`,
            html: `
        <h1>Password Reset Code</h1>
        <p>Your password reset code is: <strong>${otp}</strong></p>
        <p>This code will expire in 30 minutes.</p>
      `,
        });
        res.json({ message: 'Reset code sent successfully' });
    }
    catch (error) {
        console.error('Error in forgot password:', error);
        res.status(500).json({ error: 'Failed to process request' });
    }
}));
router.post('/verify-otp', (req, res) => {
    try {
        const { email, otp } = req.body;
        const resetToken = resetTokens.get(email);
        if (!resetToken || resetToken.token !== otp || resetToken.expires < new Date()) {
            return res.status(400).json({ error: 'Invalid or expired code' });
        }
        res.json({ message: 'Code verified successfully' });
    }
    catch (error) {
        console.error('Error in verify OTP:', error);
        res.status(500).json({ error: 'Failed to verify code' });
    }
});
router.post('/reset-password', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { email, otp, newPassword } = req.body;
        const resetToken = resetTokens.get(email);
        if (!resetToken || resetToken.token !== otp || resetToken.expires < new Date()) {
            return res.status(400).json({ error: 'Invalid or expired code' });
        }
        const salt = yield bcrypt_1.default.genSalt(10);
        const hashedPassword = yield bcrypt_1.default.hash(newPassword, salt);
        yield database_1.pool.query('UPDATE users SET password = $1 WHERE email = $2', [hashedPassword, email]);
        resetTokens.delete(email);
        res.json({ message: 'Password reset successfully' });
    }
    catch (error) {
        console.error('Error in reset password:', error);
        res.status(500).json({ error: 'Failed to reset password' });
    }
}));
router.post('/refresh', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    try {
        if (!((_a = req.user) === null || _a === void 0 ? void 0 : _a.id)) {
            return res.status(401).json({ error: 'User not found' });
        }
        const userResult = yield database_1.pool.query('SELECT id, name, email, phone, role, company_id FROM users WHERE id = $1', [req.user.id]);
        if (userResult.rows.length === 0) {
            return res.status(401).json({ error: 'User not found' });
        }
        const user = userResult.rows[0];
        const newToken = jsonwebtoken_1.default.sign({
            id: user.id,
            role: user.role,
            company_id: user.company_id
        }, auth_2.JWT_SECRET, { expiresIn: '24h' });
        res.json({
            token: newToken,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                phone: user.phone,
                role: user.role,
                company_id: user.company_id
            }
        });
    }
    catch (error) {
        console.error('Token refresh error:', error);
        res.status(500).json({ error: 'Failed to refresh token' });
    }
}));
router.get('/check-role', auth_1.verifyToken, (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        console.log('Check role request:', {
            user: req.user,
            headers: req.headers
        });
        if (!req.user) {
            return res.status(401).json({ error: 'No user found' });
        }
        res.json({
            role: req.user.role,
            id: req.user.id,
            name: req.user.name
        });
    }
    catch (error) {
        console.error('Check role error:', error);
        res.status(500).json({ error: 'Failed to check role' });
    }
}));
exports.default = router;
